CREATE TABLE IF NOT EXISTS orders (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(255),
    items VARCHAR(1000),
    status VARCHAR(20),
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);
