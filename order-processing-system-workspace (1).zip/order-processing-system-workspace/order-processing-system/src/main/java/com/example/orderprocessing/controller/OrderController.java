package com.example.orderprocessing.controller;

import com.example.orderprocessing.model.Order;
import com.example.orderprocessing.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/orders")
public class OrderController {
    @Autowired
    private OrderService orderService;

    @PostMapping
    public ResponseEntity<Order> createOrder(@RequestBody Order order) {
        Order created = orderService.createOrder(order);
        return ResponseEntity.ok(created);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Order> getOrder(@PathVariable Long id) {
        Optional<Order> order = orderService.getOrder(id);
        return order.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @GetMapping
    public List<Order> getAllOrders(@RequestParam(value = "status", required = false) String status) {
        if (status != null) {
            try {
                Order.Status st = Order.Status.valueOf(status.toUpperCase());
                return orderService.getOrdersByStatus(st);
            } catch (IllegalArgumentException e) {
                return List.of();
            }
        }
        return orderService.getAllOrders();
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<Order> updateOrderStatus(@PathVariable Long id, @RequestParam String status) {
        try {
            Order.Status st = Order.Status.valueOf(status.toUpperCase());
            Order updated = orderService.updateOrderStatus(id, st);
            if (updated != null) {
                return ResponseEntity.ok(updated);
            }
        } catch (IllegalArgumentException ignored) {}
        return ResponseEntity.badRequest().build();
    }

    @PostMapping("/{id}/cancel")
    public ResponseEntity<String> cancelOrder(@PathVariable Long id) {
        boolean canceled = orderService.cancelOrder(id);
        if (canceled) {
            return ResponseEntity.ok("Order canceled successfully.");
        } else {
            return ResponseEntity.badRequest().body("Order cannot be canceled.");
        }
    }
}
